$(document).ready(function() {
    // Listen for form submit
    $('#bmiForm').submit(function(e) {
        e.preventDefault(); // Prevent form from submitting
        var weight = $('#weight').val();
        var height = $('#height').val();
        var bmi = calculateBMI(weight, height);
        var bmiCategory = getBMICategory(bmi);
        var result = 'BMI: ' + bmi.toFixed(2) + ' (' + bmiCategory + ')';
        $('#result').text(result);
    });

    // Function to calculate BMI
    function calculateBMI(weight, height) {
        return weight / (height * height);
    }

    // Function to get BMI category
    function getBMICategory(bmi) {
        if (bmi < 18.5) {
            return 'Underweight';
        } else if (bmi >= 18.5 && bmi < 24.9) {
            return 'Normal weight';
        } else if (bmi >= 25 && bmi < 29.9) {
            return 'Overweight';
        } else if (bmi >= 30) {
            return 'Obese';
        } else {
            return 'Invalid input';
        }
    }
});
