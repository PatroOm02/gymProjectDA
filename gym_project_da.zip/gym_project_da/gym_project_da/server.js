const express = require("express");
const app = express();
const mongoose = require('mongoose');

app.use(express.urlencoded({extended:true}));

app.set("view engine","ejs");


const userSchema = new mongoose.Schema({
    fullName: {
        type:String,
        required:true
    },
    age:Number,
    gender:String,
    address:String,
    phone:Number,
    email:String
})

const User = new mongoose.model("User",userSchema);


mongoose.connect("mongodb://127.0.0.1:27017/gymdb").then(()=>console.log("DB CONNECTED")).catch((error)=>console.log(error));

app.post('/registration', async (req,res)=>{
    const {name,age,gender,address,phone,email} = req.body;
    try {
        const user = await User.create({fullName:name,age,gender,address,phone,email});
        res.end("Success!");
    } catch (error) {
        console.log(error);
        res.end(error);
    }

})

app.get("/users",async(req,res)=>{
    try {
        const users = await User.find({});
        res.render("users",{users});
    } catch (error) {
        console.log(error);
        res.end(error);
    }
})

app.listen(3000,()=>console.log("Server is working"));
